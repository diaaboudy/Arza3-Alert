# Alert Maker

Native Android app (Kotlin + Jetpack Compose) for turning a video with a black background into a transparent VP9 WebM alert.

## Features
- Pick one or several videos at once (batch queue, converted one after another; a failed file does not stop the rest, and there is a Cancel button).
- Live preview of one frame on a checkerboard (or black/white/green) background, rendered with the same FFmpeg filter as the export, with a frame seek slider.
- Tune black removal (`colorkey`) similarity and blend.
- Encode WebM using VP9 with `yuva420p` alpha and Opus audio.
- Save the result in `Downloads/AlertMaker`.
- GitHub Actions builds `app-debug.apk` and uploads it as an artifact.

## Build
Requires JDK 17. The included `gradlew` bootstraps Gradle 8.9 automatically:
```bash
chmod +x gradlew
./gradlew assembleDebug
```
APK: `app/build/outputs/apk/debug/app-debug.apk`

## GitHub Actions
Push this project to a GitHub repository. Open **Actions → Build Alert Maker APK → latest run → Artifacts** and download `AlertMaker-debug-apk`.

## Important notes
- This app uses the maintained FFmpegKit-compatible Android package `dev.ffmpegkit-maintained:ffmpeg-kit-free:6.0.2`.
- Black removal works best with a clean, pure-black background. Shadows and near-black details may also become transparent; tune Similarity and Blend.
- WebM alpha support depends on the VP9 encoder/build. This project explicitly requests `yuva420p`, disables VP9 alt-ref frames, and writes `alpha_mode=1`; validate the exported file in OBS before using it live.
- Large/high-resolution videos can take time and use substantial storage/battery. Keep the app open while exporting.
- The Gradle bootstrap script downloads Gradle 8.9 on first run; no separately installed Gradle is needed.
