package com.arza3.alertmaker

import android.app.DownloadManager
import android.content.ContentValues
import android.content.Intent
import android.graphics.BitmapFactory
import android.media.MediaMetadataRetriever
import android.net.Uri
import android.os.Bundle
import android.os.Environment
import android.provider.MediaStore
import android.view.WindowManager
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.arthenica.ffmpegkit.FFmpegKit
import com.arthenica.ffmpegkit.ReturnCode
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.suspendCancellableCoroutine
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import kotlinx.coroutines.withContext
import java.io.File
import java.io.FileOutputStream
import java.util.Locale
import kotlin.coroutines.resume
import kotlin.math.max
import kotlin.math.min

enum class ItemState { WAITING, CONVERTING, DONE, FAILED, CANCELLED }

data class AlertItem(
    val uri: Uri,
    val name: String,
    val durMs: Long,
    val state: ItemState = ItemState.WAITING,
    val progress: Float = 0f,
    val msg: String = ""
)

data class FfResult(val ok: Boolean, val log: String)

class MainActivity : ComponentActivity() {
    private val copies = HashMap<Uri, File>()
    private val copyLock = Mutex()
    private var queueJob: Job? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = android.graphics.Color.rgb(13, 16, 25)
        window.navigationBarColor = android.graphics.Color.rgb(13, 16, 25)
        // Remove temp files left over from a previous run.
        cacheDir.listFiles()?.forEach {
            if (it.name.startsWith("src_") || it.name.startsWith("alert_") || it.name.startsWith("preview_")) it.delete()
        }
        setContent { AlertMakerScreen() }
    }

    @Composable
    private fun AlertMakerScreen() {
        val scope = rememberCoroutineScope()
        val list = remember { mutableStateListOf<AlertItem>() }
        var selected by remember { mutableIntStateOf(0) }
        var similarity by remember { mutableFloatStateOf(0.18f) }
        var blend by remember { mutableFloatStateOf(0.08f) }
        var seekSec by remember { mutableFloatStateOf(1f) }
        var previewBg by remember { mutableIntStateOf(0) }
        var preview by remember { mutableStateOf<ImageBitmap?>(null) }
        var previewLoading by remember { mutableStateOf(false) }
        var previewError by remember { mutableStateOf<String?>(null) }
        var busy by remember { mutableStateOf(false) }

        val simS = fmt(similarity)
        val blS = fmt(blend)
        val cur = list.getOrNull(selected)

        val picker = rememberLauncherForActivityResult(ActivityResultContracts.OpenMultipleDocuments()) { uris ->
            if (uris.isNotEmpty()) {
                scope.launch {
                    val added = withContext(Dispatchers.IO) {
                        uris.filter { u -> list.none { it.uri == u } }.map { u ->
                            try { contentResolver.takePersistableUriPermission(u, Intent.FLAG_GRANT_READ_URI_PERMISSION) } catch (_: Exception) {}
                            AlertItem(u, queryDisplayName(u) ?: "video", durationMs(u))
                        }
                    }
                    list.addAll(added)
                }
            }
        }

        // Pick a sensible default frame when the selected video changes.
        LaunchedEffect(cur?.uri) {
            if (cur != null) {
                seekSec = if (cur.durMs > 0) min(1f, cur.durMs / 2000f) else 0f
            } else {
                preview = null
                previewError = null
            }
        }

        // Live preview: one frame, rendered by FFmpeg with the same filter as the export.
        LaunchedEffect(cur?.uri, simS, blS, seekSec, busy) {
            if (cur == null || busy) { previewLoading = false; return@LaunchedEffect }
            previewLoading = true
            delay(400)
            val (bmp, err) = renderPreview(cur, simS, blS, seekSec)
            if (bmp != null) { preview = bmp; previewError = null } else previewError = err
            previewLoading = false
        }

        fun removeAt(i: Int) {
            dropCopy(list[i].uri)
            list.removeAt(i)
            if (selected >= list.size) selected = max(0, list.size - 1) else if (i < selected) selected -= 1
        }

        fun startQueue() {
            if (busy || list.none { it.state != ItemState.DONE }) return
            for (i in list.indices) {
                if (list[i].state != ItemState.DONE) list[i] = list[i].copy(state = ItemState.WAITING, progress = 0f, msg = "")
            }
            busy = true
            window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
            queueJob = scope.launch {
                try {
                    for (i in list.indices) {
                        if (list[i].state == ItemState.DONE) continue
                        list[i] = list[i].copy(state = ItemState.CONVERTING, progress = 0f)
                        val err = convertOne(list[i], simS, blS) { p ->
                            runOnUiThread {
                                if (i < list.size && list[i].state == ItemState.CONVERTING) list[i] = list[i].copy(progress = p)
                            }
                        }
                        list[i] = if (err == null) list[i].copy(state = ItemState.DONE, progress = 1f, msg = "")
                        else list[i].copy(state = ItemState.FAILED, msg = err)
                    }
                } finally {
                    for (i in list.indices) {
                        if (list[i].state == ItemState.CONVERTING) list[i] = list[i].copy(state = ItemState.CANCELLED)
                    }
                    busy = false
                    window.clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
                }
            }
        }

        val doneN = list.count { it.state == ItemState.DONE }
        val failedN = list.count { it.state == ItemState.FAILED }
        val pendingN = list.count { it.state != ItemState.DONE }

        MaterialTheme(
            colorScheme = darkColorScheme(
                primary = Color(0xFF8B7CFF),
                secondary = Color(0xFF27D7B0),
                background = Color(0xFF0D1019),
                surface = Color(0xFF171C2A)
            )
        ) {
            Surface(Modifier.fillMaxSize(), color = Color(0xFF0D1019)) {
                Column(
                    Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(20.dp),
                    verticalArrangement = Arrangement.spacedBy(18.dp)
                ) {
                    Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                        Text("ALERT MAKER", color = Color.White, fontSize = 27.sp)
                        Text("Transparent alerts for your live stream", color = Color(0xFF9AA5BC))
                    }

                    // 1. Choose videos
                    Card(colors = CardDefaults.cardColors(containerColor = Color(0xFF171C2A))) {
                        Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                            Text("1. Choose your videos", color = Color.White, fontSize = 18.sp)
                            if (list.isEmpty()) {
                                Text("No videos selected. You can pick several at once.", color = Color(0xFFABB4C8), fontSize = 13.sp)
                            }
                            list.forEachIndexed { i, item ->
                                Column(
                                    Modifier.fillMaxWidth()
                                        .clip(RoundedCornerShape(10.dp))
                                        .border(
                                            if (i == selected) 2.dp else 1.dp,
                                            if (i == selected) Color(0xFF8B7CFF) else Color(0xFF2E3550),
                                            RoundedCornerShape(10.dp)
                                        )
                                        .clickable { selected = i }
                                        .padding(10.dp),
                                    verticalArrangement = Arrangement.spacedBy(6.dp)
                                ) {
                                    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                        Text(item.name, color = Color.White, fontSize = 14.sp, maxLines = 1,
                                            overflow = TextOverflow.Ellipsis, modifier = Modifier.weight(1f))
                                        val (label, col) = when (item.state) {
                                            ItemState.WAITING -> "Waiting" to Color(0xFF9AA5BC)
                                            ItemState.CONVERTING -> "${(item.progress * 100).toInt()}%" to Color(0xFF8B7CFF)
                                            ItemState.DONE -> "Done ✓" to Color(0xFF27D7B0)
                                            ItemState.FAILED -> "Failed" to Color(0xFFFF8B8B)
                                            ItemState.CANCELLED -> "Cancelled" to Color(0xFFFFC46B)
                                        }
                                        Text(label, color = col, fontSize = 13.sp)
                                        if (!busy) {
                                            Text("✕", color = Color(0xFF9AA5BC), fontSize = 16.sp,
                                                modifier = Modifier.clickable { removeAt(i) }.padding(4.dp))
                                        }
                                    }
                                    if (item.state == ItemState.CONVERTING || item.state == ItemState.DONE) {
                                        LinearProgressIndicator(progress = { item.progress }, modifier = Modifier.fillMaxWidth())
                                    }
                                    if (item.msg.isNotEmpty()) {
                                        Text(item.msg, color = Color(0xFFFF8B8B), fontSize = 11.sp, maxLines = 3, overflow = TextOverflow.Ellipsis)
                                    }
                                }
                            }
                            Button(onClick = { picker.launch(arrayOf("video/*")) }, enabled = !busy, modifier = Modifier.fillMaxWidth()) {
                                Text(if (list.isEmpty()) "SELECT VIDEOS" else "ADD MORE VIDEOS")
                            }
                        }
                    }

                    // 2. Preview + black removal
                    Card(colors = CardDefaults.cardColors(containerColor = Color(0xFF171C2A))) {
                        Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                            Text("2. Remove black background", color = Color.White, fontSize = 18.sp)
                            PreviewBox(preview, previewLoading, previewBg, previewError, cur != null)
                            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                                Text("Background", color = Color(0xFF9AA5BC), fontSize = 13.sp)
                                listOf(Color(0xFF3A3F58), Color.Black, Color.White, Color(0xFF12C24A)).forEachIndexed { i, c ->
                                    Box(
                                        Modifier.size(34.dp).clip(RoundedCornerShape(8.dp)).background(c)
                                            .border(if (previewBg == i) 2.dp else 1.dp,
                                                if (previewBg == i) Color(0xFF8B7CFF) else Color(0xFF4A5170),
                                                RoundedCornerShape(8.dp))
                                            .clickable { previewBg = i },
                                        contentAlignment = Alignment.Center
                                    ) { if (i == 0) Text("▦", color = Color(0xFFABB4C8), fontSize = 14.sp) }
                                }
                            }
                            if (cur != null && cur.durMs > 0) {
                                val maxSec = max(0.1f, cur.durMs / 1000f - 0.2f)
                                Text("Preview frame  •  ${"%.1f".format(Locale.US, seekSec.coerceIn(0f, maxSec))}s", color = Color(0xFFB8C2D8))
                                Slider(value = seekSec.coerceIn(0f, maxSec), onValueChange = { seekSec = it }, valueRange = 0f..maxSec)
                            }
                            Text("Similarity  •  $simS", color = Color(0xFFB8C2D8))
                            Slider(value = similarity, onValueChange = { similarity = it }, valueRange = 0.02f..0.50f, enabled = !busy)
                            Text("Blend / edge softness  •  $blS", color = Color(0xFFB8C2D8))
                            Slider(value = blend, onValueChange = { blend = it }, valueRange = 0f..0.25f, enabled = !busy)
                            Text("Tip: Increase Similarity to remove more dark pixels. Increase Blend for softer edges. The preview uses the same filter as the export.",
                                color = Color(0xFF8793AA), fontSize = 12.sp)
                        }
                    }

                    // 3. Export
                    Card(colors = CardDefaults.cardColors(containerColor = Color(0xFF171C2A))) {
                        Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                            Text("3. Export transparent WebM", color = Color.White, fontSize = 18.sp)
                            Text("Format: WebM • VP9 • Alpha • Opus audio", color = Color(0xFFABB4C8), fontSize = 13.sp)
                            Button(
                                onClick = { startQueue() },
                                enabled = pendingN > 0 && !busy,
                                modifier = Modifier.fillMaxWidth()
                            ) {
                                Text(
                                    when {
                                        busy -> "EXPORTING ${min(doneN + failedN + 1, list.size)} / ${list.size}…"
                                        list.isEmpty() -> "REMOVE BLACK & EXPORT"
                                        pendingN == 0 -> "ALL DONE"
                                        else -> "REMOVE BLACK & EXPORT ($pendingN)"
                                    }
                                )
                            }
                            if (busy) {
                                OutlinedButton(onClick = { queueJob?.cancel() }, modifier = Modifier.fillMaxWidth()) { Text("CANCEL") }
                                Text("Keep the app open while exporting. The screen stays on.", color = Color(0xFF8793AA), fontSize = 12.sp)
                            } else if (doneN + failedN > 0) {
                                Text("Finished: $doneN done" + if (failedN > 0) ", $failedN failed" else "",
                                    color = if (failedN > 0) Color(0xFFFFC46B) else Color(0xFF27D7B0), fontSize = 13.sp)
                                if (doneN > 0) {
                                    Text("Saved in Downloads/AlertMaker", color = Color(0xFFABB4C8), fontSize = 12.sp)
                                    OutlinedButton(
                                        onClick = {
                                            try {
                                                startActivity(Intent(DownloadManager.ACTION_VIEW_DOWNLOADS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
                                            } catch (_: Exception) {}
                                        },
                                        modifier = Modifier.fillMaxWidth()
                                    ) { Text("OPEN DOWNLOADS") }
                                }
                            }
                        }
                    }
                    Text("Made for TikTok Live • OBS • transparent alerts", color = Color(0xFF65718A), fontSize = 11.sp,
                        modifier = Modifier.align(Alignment.CenterHorizontally))
                }
            }
        }
    }

    // ---------- FFmpeg helpers ----------

    private fun fmt(v: Float): String = "%.2f".format(Locale.US, v)

    private fun quote(value: String): String = "'" + value.replace("'", "'\\''") + "'"

    /** Runs FFmpeg and cancels the session if the calling coroutine is cancelled. */
    private suspend fun runFfmpeg(command: String, onTimeMs: (Double) -> Unit = {}): FfResult =
        suspendCancellableCoroutine { cont ->
            val session = FFmpegKit.executeAsync(
                command,
                { s ->
                    val ok = ReturnCode.isSuccess(s.returnCode)
                    val log = if (ok) "" else (s.failStackTrace ?: s.allLogsAsString ?: "Unknown FFmpeg error")
                    if (cont.isActive) cont.resume(FfResult(ok, log.takeLast(400)))
                },
                { _ -> },
                { st -> onTimeMs(st.time.toDouble()) }
            )
            cont.invokeOnCancellation { FFmpegKit.cancel(session.sessionId) }
        }

    private suspend fun ensureCopy(uri: Uri): File = copyLock.withLock {
        withContext(Dispatchers.IO) {
            val existing = synchronized(copies) { copies[uri] }
            if (existing != null && existing.exists()) {
                existing
            } else {
                val f = File(cacheDir, "src_${System.nanoTime()}.video")
                contentResolver.openInputStream(uri).use { input ->
                    requireNotNull(input) { "Cannot read the selected video." }
                    FileOutputStream(f).use { output -> input.copyTo(output) }
                }
                synchronized(copies) { copies[uri] = f }
                f
            }
        }
    }

    private fun dropCopy(uri: Uri) {
        synchronized(copies) { copies.remove(uri) }?.delete()
    }

    private suspend fun renderPreview(item: AlertItem, sim: String, bl: String, sec: Float): Pair<ImageBitmap?, String?> {
        return try {
            val src = ensureCopy(item.uri)
            val out = File(cacheDir, "preview_${System.nanoTime()}.png")
            val t = "%.3f".format(Locale.US, max(0f, sec))
            val cmd = "-y -ss $t -i ${quote(src.absolutePath)} -frames:v 1 " +
                "-vf \"colorkey=0x000000:$sim:$bl,scale=480:-2,format=rgba\" ${quote(out.absolutePath)}"
            val r = runFfmpeg(cmd)
            val bmp = withContext(Dispatchers.IO) {
                val b = if (r.ok && out.exists()) BitmapFactory.decodeFile(out.absolutePath) else null
                out.delete()
                b
            }
            if (bmp != null) Pair(bmp.asImageBitmap(), null)
            else Pair(null, "Could not render a preview frame. ${r.log.takeLast(120)}")
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            Pair(null, "Preview error: ${e.message}")
        }
    }

    /** Converts one video. Returns null on success or an error message. */
    private suspend fun convertOne(item: AlertItem, sim: String, bl: String, onProgress: (Float) -> Unit): String? {
        var target: File? = null
        try {
            val source = ensureCopy(item.uri)
            val t = File(cacheDir, "alert_${System.nanoTime()}.webm")
            target = t
            // VP9 + yuva420p preserves the alpha channel in WebM.
            val command = "-y -i ${quote(source.absolutePath)} " +
                "-vf \"colorkey=0x000000:$sim:$bl,format=yuva420p\" " +
                "-c:v libvpx-vp9 -pix_fmt yuva420p -auto-alt-ref 0 " +
                "-metadata:s:v:0 alpha_mode=1 -crf 30 -b:v 0 " +
                "-c:a libopus -b:a 128k ${quote(t.absolutePath)}"
            val r = runFfmpeg(command) { ms ->
                if (item.durMs > 0) onProgress((ms / item.durMs).toFloat().coerceIn(0f, 0.99f))
            }
            if (!r.ok || !t.exists() || t.length() == 0L) return "Export failed: ${r.log}"
            saveToDownloads(t, outputName(item.name))
            return null
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            return "Error: ${e.message ?: "Could not process video"}"
        } finally {
            target?.delete()
            dropCopy(item.uri)
        }
    }

    private fun outputName(original: String): String {
        val stem = original.substringBeforeLast('.')
            .replace(Regex("[^\\p{L}\\p{N}_\\- ]"), "_").trim().take(80)
        return (if (stem.isEmpty()) "alert" else stem) + ".webm"
    }

    private fun durationMs(uri: Uri): Long {
        val r = MediaMetadataRetriever()
        return try {
            r.setDataSource(this, uri)
            r.extractMetadata(MediaMetadataRetriever.METADATA_KEY_DURATION)?.toLongOrNull() ?: 0L
        } catch (_: Exception) {
            0L
        } finally {
            try { r.release() } catch (_: Exception) {}
        }
    }

    private fun queryDisplayName(uri: Uri): String? {
        return contentResolver.query(uri, arrayOf(MediaStore.MediaColumns.DISPLAY_NAME), null, null, null)?.use {
            if (it.moveToFirst()) it.getString(0) else null
        }
    }

    private suspend fun saveToDownloads(source: File, name: String): String = withContext(Dispatchers.IO) {
        val values = ContentValues().apply {
            put(MediaStore.MediaColumns.DISPLAY_NAME, name)
            put(MediaStore.MediaColumns.MIME_TYPE, "video/webm")
            put(MediaStore.MediaColumns.RELATIVE_PATH, Environment.DIRECTORY_DOWNLOADS + "/AlertMaker")
            put(MediaStore.MediaColumns.IS_PENDING, 1)
        }
        val uri = contentResolver.insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, values)
            ?: error("Could not create output file")
        try {
            contentResolver.openOutputStream(uri)?.use { out -> source.inputStream().use { it.copyTo(out) } }
                ?: error("Could not write output file")
            values.clear()
            values.put(MediaStore.MediaColumns.IS_PENDING, 0)
            contentResolver.update(uri, values, null, null)
            name
        } catch (e: Exception) {
            contentResolver.delete(uri, null, null)
            throw e
        }
    }
}

@Composable
private fun PreviewBox(bmp: ImageBitmap?, loading: Boolean, bg: Int, error: String?, hasVideo: Boolean) {
    Box(
        Modifier.fillMaxWidth().height(300.dp).clip(RoundedCornerShape(12.dp)),
        contentAlignment = Alignment.Center
    ) {
        Canvas(Modifier.matchParentSize()) {
            when (bg) {
                0 -> {
                    val s = 16.dp.toPx()
                    val cols = (size.width / s).toInt() + 1
                    val rows = (size.height / s).toInt() + 1
                    for (r in 0 until rows) for (c in 0 until cols) {
                        drawRect(
                            if ((r + c) % 2 == 0) Color(0xFF3A3F58) else Color(0xFF2B2F45),
                            topLeft = Offset(c * s, r * s), size = Size(s, s)
                        )
                    }
                }
                1 -> drawRect(Color.Black)
                2 -> drawRect(Color.White)
                else -> drawRect(Color(0xFF12C24A))
            }
        }
        if (bmp != null && hasVideo) {
            Image(bitmap = bmp, contentDescription = "Preview", modifier = Modifier.fillMaxSize(), contentScale = ContentScale.Fit)
        }
        if (!hasVideo) {
            Text("Select a video to see the preview", color = Color(0xFFABB4C8), fontSize = 13.sp)
        } else if (loading) {
            CircularProgressIndicator(modifier = Modifier.size(28.dp), strokeWidth = 3.dp)
        } else if (error != null && bmp == null) {
            Text(error, color = Color(0xFFFF8B8B), fontSize = 11.sp, modifier = Modifier.padding(12.dp))
        }
    }
}
